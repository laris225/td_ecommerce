import 'package:flutter/material.dart';

import 'screen/homepage.dart';
import 'screen/produit.dart';
import 'screen/cart.dart';
import 'screen/bloc.dart';
import 'screen/type.dart';
import 'screen/type2.dart';
import 'screen/type3.dart';
import 'screen/type4.dart';
import 'screen/type5.dart';
import 'screen/type6.dart';
import 'screen/type7.dart';
import 'screen/type8.dart';
import 'screen/type9.dart';
import 'screen/type10.dart';
import 'screen/type11.dart';
import 'screen/type12.dart';
import 'screen/type13.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "ecommerce",
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Homepage(),
      routes: {
        'infoproduit': (context) => InfoProd(),
        'cart': (context) => Cart(),
        'bloc': (context) => Bloc(),
        'type': (context) => Type(),
        'type2': (context) => Type2(),
        'type3': (context) => Type3(),
        'type4': (context) => Type4(),
        'type5': (context) => Type5(),
        'type6': (context) => Type6(),
        'type7': (context) => Type7(),
        'type8': (context) => Type8(),
        'type9': (context) => Type9(),
        'type10': (context) => Type10(),
        'type11': (context) => Type11(),
        'type12': (context) => Type12(),
        'type13': (context) => Type13(),
      },
    );
  }
}
