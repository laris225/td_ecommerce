// Pour les appeler directirectement dans notre fichier, o fait:
// "nom": prevData[i]["nameData"],
// "nom": sympData[i]["imgData"],

List prevData = [
  {
    "imgData": "images/malade6.png",
    "nameData": "Utiliser un masque",
    "msgData":
        "quand les éternuements ne sont même pas un symptôme de coronavirus.",
  },
  {
    "imgData": "images/malade10.png",
    "nameData": "laver les mains",
    "msgData":
        "quand les éternuements ne sont même pas un symptôme de coronavirus.",
  },
  {
    "imgData": "images/malade12.png",
    "nameData": "éviter le contact avec les animaux",
    "msgData":
        "quand les éternuements ne sont même pas un symptôme de coronavirus.",
  },
  {
    "imgData": "images/fraiche.png",
    "nameData": "Manger les aliments cuits",
    "msgData":
        "quand les éternuements ne sont même pas un symptôme de coronavirus.",
  }
];

List sympData = [
  {
    "imgData": "images/malade4.png",
    "nameData": "Forte Fièvre",
    "nmbData": "87 discussions",
  },
  {
    "imgData": "images/malade2.png",
    "nameData": "Toux Sèche",
    "nmbData": "203 discussions",
  }
];
