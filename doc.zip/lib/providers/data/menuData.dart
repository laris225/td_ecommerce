List menuData = [
  {
    'name': 'Fauteuils',
  },
  {
    'name': 'Chaussures',
  },
  {
    'name': 'Vêtements',
  },
  {
    'name': 'Téléphones',
  },
  {
    'name': 'Electroménagé',
  },
  {
    'name': 'Nourritures',
  },
  {
    'name': 'Véhicules',
  },
];
