import 'package:flutter/material.dart';

class Bloc extends StatelessWidget {
  const Bloc({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Padding(
        padding: const EdgeInsets.only(top: 30),
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.black,
          child: ListView.builder(
            itemCount: 5,
            itemBuilder: (context, i) {
              return Container(
                // margin: EdgeInsets.only(bottom: 20),
                height: 330,
                width: MediaQuery.of(context).size.width / 1.1,
                child: Column(
                  children: <Widget>[
                    Container(
                      height: 320,
                      width: MediaQuery.of(context).size.width / 1.1,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                      ),
                      child: Column(
                        children: <Widget>[
                          Container(
                            height: 150,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10),
                              ),
                              color: Colors.white,
                              image: (i % 2 == 0)
                                  ? DecorationImage(
                                      image: AssetImage("images/avocat.png"),
                                      fit: BoxFit.cover)
                                  : DecorationImage(
                                      image: AssetImage("images/fruit.png"),
                                      fit: BoxFit.cover),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 10, top: 10, right: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Row(
                                      children: <Widget>[
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                        Icon(
                                          Icons.star,
                                          color: Color(0XFFFDCF7A),
                                          size: 20,
                                        ),
                                      ],
                                    ),
                                    Column(
                                      children: <Widget>[
                                        Icon(
                                          Icons.favorite,
                                          color: Colors.red,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Container(
                                  width: 240,
                                  child: (i % 2 == 0)
                                      ? Text(
                                          "Avocado and Eggs with full grain bread",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                        )
                                      : Text(
                                          "Greek yogurt with granola and red fruits",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 20),
                                        ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Container(
                                  width: MediaQuery.of(context).size.width,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Container(
                                        width:
                                            MediaQuery.of(context).size.width /
                                                2.5,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Container(
                                              width: 105,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: <Widget>[
                                                  Text(
                                                    "Calories",
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      (i % 2 == 0)
                                                          ? Text(
                                                              "600",
                                                              style: TextStyle(
                                                                  fontSize: 16),
                                                            )
                                                          : Text(
                                                              "350",
                                                              style: TextStyle(
                                                                  fontSize: 16),
                                                            ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: 110,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: <Widget>[
                                                  Text(
                                                    "Carbs",
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      Text(
                                                        "60gr",
                                                        style: TextStyle(
                                                            fontSize: 16),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                            Container(
                                              width: 110,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: <Widget>[
                                                  Text(
                                                    "Protein",
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                  ),
                                                  Column(
                                                    children: <Widget>[
                                                      (i % 2 == 0)
                                                          ? Text(
                                                              "30gr",
                                                              style: TextStyle(
                                                                  fontSize: 16),
                                                            )
                                                          : Text(
                                                              "9gr",
                                                              style: TextStyle(
                                                                  fontSize: 16),
                                                            ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Column(
                                        children: <Widget>[
                                          Container(
                                            alignment: Alignment.center,
                                            height: 60,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                2.4,
                                            decoration: (i % 2 == 0)
                                                ? BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: Colors.indigo[400],
                                                  )
                                                : BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    color: Colors.white,
                                                    border: Border.all(
                                                        color: Colors.grey,
                                                        width: 1),
                                                  ),
                                            child: (i % 2 == 0)
                                                ? Text(
                                                    "Add to my week",
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 17),
                                                  )
                                                : Text(
                                                    "Add to my week",
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 17),
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

// Container(
//                 height: 320,
//                 width: MediaQuery.of(context).size.width / 1.1,
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(10),
//                   color: Colors.white,
//                 ),
//                 child: Column(
//                   children: <Widget>[
//                     Container(
//                       height: 150,
//                       width: MediaQuery.of(context).size.width,
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.only(
//                           topLeft: Radius.circular(10),
//                           topRight: Radius.circular(10),
//                         ),
//                         color: Colors.white,
//                         image: DecorationImage(
//                             image: AssetImage("images/avocat.png"),
//                             fit: BoxFit.cover),
//                       ),
//                     ),
//                     Padding(
//                       padding:
//                           const EdgeInsets.only(left: 10, top: 10, right: 10),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: <Widget>[
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: <Widget>[
//                               Row(
//                                 children: <Widget>[
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                   Icon(
//                                     Icons.star,
//                                     color: Color(0XFFFDCF7A),
//                                     size: 20,
//                                   ),
//                                 ],
//                               ),
//                               Column(
//                                 children: <Widget>[
//                                   Icon(
//                                     Icons.favorite,
//                                     color: Colors.red,
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Container(
//                             width: 240,
//                             child: Text(
//                               "Avocado and Eggs with full grain bread",
//                               style: TextStyle(
//                                   fontWeight: FontWeight.bold, fontSize: 20),
//                             ),
//                           ),
//                           SizedBox(
//                             height: 5,
//                           ),
//                           Container(
//                             width: MediaQuery.of(context).size.width,
//                             child: Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: <Widget>[
//                                 Container(
//                                   width:
//                                       MediaQuery.of(context).size.width / 2.5,
//                                   child: Column(
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.start,
//                                     children: <Widget>[
//                                       Container(
//                                         width: 105,
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceBetween,
//                                           children: <Widget>[
//                                             Text(
//                                               "Calories",
//                                               style: TextStyle(
//                                                   color: Colors.grey,
//                                                   fontSize: 15),
//                                             ),
//                                             Column(
//                                               children: <Widget>[
//                                                 Text(
//                                                   "600",
//                                                   style:
//                                                       TextStyle(fontSize: 16),
//                                                 ),
//                                               ],
//                                             )
//                                           ],
//                                         ),
//                                       ),
//                                       Container(
//                                         width: 110,
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceBetween,
//                                           children: <Widget>[
//                                             Text(
//                                               "Carbs",
//                                               style: TextStyle(
//                                                   color: Colors.grey,
//                                                   fontSize: 15),
//                                             ),
//                                             Column(
//                                               children: <Widget>[
//                                                 Text(
//                                                   "60gr",
//                                                   style:
//                                                       TextStyle(fontSize: 16),
//                                                 ),
//                                               ],
//                                             )
//                                           ],
//                                         ),
//                                       ),
//                                       Container(
//                                         width: 110,
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceBetween,
//                                           children: <Widget>[
//                                             Text(
//                                               "Protein",
//                                               style: TextStyle(
//                                                   color: Colors.grey,
//                                                   fontSize: 15),
//                                             ),
//                                             Column(
//                                               children: <Widget>[
//                                                 Text(
//                                                   "30gr",
//                                                   style:
//                                                       TextStyle(fontSize: 16),
//                                                 ),
//                                               ],
//                                             )
//                                           ],
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                                 Column(
//                                   children: <Widget>[
//                                     Container(
//                                       alignment: Alignment.center,
//                                       height: 60,
//                                       width: MediaQuery.of(context).size.width /
//                                           2.4,
//                                       decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(10),
//                                         color: Colors.indigo[400],
//                                       ),
//                                       child: Text(
//                                         "Add to my week",
//                                         style: TextStyle(
//                                             color: Colors.white, fontSize: 17),
//                                       ),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
