import '../providers/model/categoriemodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int index = 0;
  List<Categoriemodel> cat = [];
  List<Produit> prod = [];
  @override
  void initState() {
    // TODO: implement initState
    getcategorie();
    super.initState();
  }

  Future getcategorie() async {
    List<Categoriemodel> res = await Categoriemodel().loadchargerJson();
    print(res);
    if (res != null) {
      setState(() {
        cat = res;
      });
    }
  }

  Future getproduit() async {
    List<Produit> res = await Produit().loadchargerJson1();
    print(res);
    if (res != null) {
      setState(() {
        prod = res;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          "O'Djassa",
          style: TextStyle(
              color: Colors.black,
              fontSize: 30,
              letterSpacing: 1.8,
              fontWeight: FontWeight.w900,
              fontFamily: "cursive"),
        ),
        actions: <Widget>[
          IconButton(
              icon: Icon(
                Icons.shopping_basket,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pushNamed(context, "cart");
              }),
          IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pushNamed(context, "bloc");
              }),
          IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.black,
              ),
              onPressed: () {
                Navigator.pushNamed(context, "type");
              })
        ],
      ),
      drawer: Drawer(),
      body: Container(
        child: Column(
          children: <Widget>[
            Container(
              width: MediaQuery.of(context).size.width,
              height: 50,
              child: ListView.builder(
                itemCount: cat.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, i) => InkWell(
                  onTap: () {
                    setState(() {
                      this.index = i;
                      print(index);
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      child: Text(
                        cat[i].nom,
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: IndexedStack(
                index: index,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 18,
                                          ),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 190,
                              childAspectRatio: 0.7,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 10,
                            ),
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "infoproduit");
                                },
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: <Widget>[
                                    Card(
                                      elevation: 12,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        height: 300,
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                height: 90,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      cat[index]
                                                          .produit[i]
                                                          .image,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    cat[index].produit[i].nom,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20),
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    cat[index]
                                                        .produit[i]
                                                        .description,
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "\$" +
                                                        cat[index]
                                                            .produit[i]
                                                            .prix
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: -5,
                                      right: -2,
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFFDCF7A)),
                                        child: IconButton(
                                            icon: Icon(
                                              Icons.shopping_basket,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                  context, 'cart');
                                            }),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 190,
                              childAspectRatio: 0.7,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 10,
                            ),
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "infoproduit");
                                },
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: <Widget>[
                                    Card(
                                      elevation: 12,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        height: 300,
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                height: 90,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      cat[index]
                                                          .produit[i]
                                                          .image,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    cat[index].produit[i].nom,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20),
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    cat[index]
                                                        .produit[i]
                                                        .description,
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "\$" +
                                                        cat[index]
                                                            .produit[i]
                                                            .prix
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: -5,
                                      right: -2,
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFFDCF7A)),
                                        child: IconButton(
                                            icon: Icon(
                                              Icons.shopping_basket,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                  context, 'cart');
                                            }),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 190,
                              childAspectRatio: 0.7,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 10,
                            ),
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "infoproduit");
                                },
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: <Widget>[
                                    Card(
                                      elevation: 12,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        height: 300,
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                height: 90,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      cat[index]
                                                          .produit[i]
                                                          .image,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    cat[index].produit[i].nom,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20),
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    cat[index]
                                                        .produit[i]
                                                        .description,
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "\$" +
                                                        cat[index]
                                                            .produit[i]
                                                            .prix
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: -5,
                                      right: -2,
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFFDCF7A)),
                                        child: IconButton(
                                            icon: Icon(
                                              Icons.shopping_basket,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                  context, 'cart');
                                            }),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 190,
                              childAspectRatio: 0.7,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 10,
                            ),
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "infoproduit");
                                },
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: <Widget>[
                                    Card(
                                      elevation: 12,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        height: 300,
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                height: 90,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      cat[index]
                                                          .produit[i]
                                                          .image,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    cat[index].produit[i].nom,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20),
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    cat[index]
                                                        .produit[i]
                                                        .description,
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "\$" +
                                                        cat[index]
                                                            .produit[i]
                                                            .prix
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: -5,
                                      right: -2,
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFFDCF7A)),
                                        child: IconButton(
                                            icon: Icon(
                                              Icons.shopping_basket,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                  context, 'cart');
                                            }),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 190,
                              childAspectRatio: 0.7,
                              crossAxisSpacing: 0,
                              mainAxisSpacing: 10,
                            ),
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "infoproduit");
                                },
                                child: Stack(
                                  overflow: Overflow.visible,
                                  children: <Widget>[
                                    Card(
                                      elevation: 12,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          color: Colors.white,
                                        ),
                                        height: 300,
                                        child: Column(
                                          children: <Widget>[
                                            Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Container(
                                                height: 90,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  color: Colors.white,
                                                  image: DecorationImage(
                                                    image: AssetImage(
                                                      cat[index]
                                                          .produit[i]
                                                          .image,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    cat[index].produit[i].nom,
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 20),
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(
                                                    cat[index]
                                                        .produit[i]
                                                        .description,
                                                    style: TextStyle(
                                                        color: Colors.grey,
                                                        fontSize: 15),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Text(
                                                    "\$" +
                                                        cat[index]
                                                            .produit[i]
                                                            .prix
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontSize: 20,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: -5,
                                      right: -2,
                                      child: Container(
                                        height: 35,
                                        width: 35,
                                        decoration: BoxDecoration(
                                            color: Color(0XFFFDCF7A)),
                                        child: IconButton(
                                            icon: Icon(
                                              Icons.shopping_basket,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                  context, 'cart');
                                            }),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                      )
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 20,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                cat[index].produit.length.toString() +
                                    " Produit(s)",
                                style: TextStyle(
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                ),
                              ),
                              Column(
                                children: <Widget>[
                                  Container(
                                    height: 20,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          "Popular",
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Icon(
                                          Icons.keyboard_arrow_down,
                                          color: Colors.black,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: GridView.builder(
                          itemCount: cat[index].produit.length /*prod.length*/,
                          gridDelegate:
                              SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 190,
                            childAspectRatio: 0.7,
                            crossAxisSpacing: 0,
                            mainAxisSpacing: 10,
                          ),
                          itemBuilder: (context, i) {
                            return InkWell(
                              onTap: () {
                                Navigator.pushNamed(context, "infoproduit");
                              },
                              child: Stack(
                                overflow: Overflow.visible,
                                children: <Widget>[
                                  Card(
                                    elevation: 12,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Colors.white,
                                      ),
                                      height: 300,
                                      child: Column(
                                        children: <Widget>[
                                          Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Container(
                                              height: 90,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: Colors.white,
                                                image: DecorationImage(
                                                  image: AssetImage(
                                                    cat[index].produit[i].image,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(left: 15),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  cat[index].produit[i].nom,
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontSize: 20),
                                                ),
                                                SizedBox(
                                                  height: 5,
                                                ),
                                                Text(
                                                  cat[index]
                                                      .produit[i]
                                                      .description,
                                                  style: TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 15),
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  "\$" +
                                                      cat[index]
                                                          .produit[i]
                                                          .prix
                                                          .toString(),
                                                  style: TextStyle(
                                                      color: Colors.black,
                                                      fontSize: 20,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: -5,
                                    right: -2,
                                    child: Container(
                                      height: 35,
                                      width: 35,
                                      decoration: BoxDecoration(
                                          color: Color(0XFFFDCF7A)),
                                      child: IconButton(
                                          icon: Icon(
                                            Icons.shopping_basket,
                                            color: Colors.white,
                                            size: 18,
                                          ),
                                          onPressed: () {
                                            Navigator.pushNamed(
                                                context, 'cart');
                                          }),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
