import 'package:flutter/material.dart';
import 'dart:math' as math;

import '../providers/model/categorietype.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart';
import 'package:provider/provider.dart';

class Type extends StatefulWidget {
  const Type({Key key}) : super(key: key);

  @override
  _TypeState createState() => _TypeState();
}

class _TypeState extends State<Type> {
  int index = 0;
  List<Categorietype> cat = [];
  List<Produittype> prod = [];
  @override
  void initState() {
    // TODO: implement initState
    getcategorie();
    super.initState();
  }

  Future getcategorie() async {
    List<Categorietype> res = await Categorietype().loadchargerJson();
    print(res);
    if (res != null) {
      setState(() {
        cat = res;
      });
    }
  }

  Future getproduit() async {
    List<Produittype> res = await Produittype().loadchargerJson1();
    print(res);
    if (res != null) {
      setState(() {
        prod = res;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.short_text),
          color: Colors.black,
          iconSize: 30,
          onPressed: () {},
        ),
        actions: <Widget>[
          Stack(
            children: <Widget>[
              Container(
                child: IconButton(
                  icon: Icon(Icons.shopping_cart),
                  color: Colors.black,
                  iconSize: 30,
                  onPressed: () {
                    Navigator.pushNamed(context, "type3");
                  },
                ),
              ),
              Positioned(
                right: 10,
                top: 5,
                child: CircleAvatar(
                  maxRadius: 7,
                  backgroundColor: Colors.blue,
                  child: Text(
                    "3",
                    style: TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
              child: Container(
                width: 250,
                child: Text(
                  "DISCOVER THE NEWEST SHOES",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Card(
                  color: Colors.white,
                  elevation: 15,
                  child: Container(
                    color: Colors.white,
                    width: MediaQuery.of(context).size.width / 1.5,
                    height: 40,
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(
                          Icons.search,
                          color: Colors.grey,
                          size: 25,
                        ),
                        hintText: "search shoes",
                        hintStyle: TextStyle(color: Colors.grey),
                      ),
                    ),
                  ),
                ),
                Icon(
                  Icons.sort,
                  color: Colors.black,
                  size: 35,
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 50,
                child: ListView.builder(
                  itemCount: cat.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, i) => InkWell(
                    onTap: () {
                      setState(() {
                        this.index = i;
                        print(index);
                      });
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        child: Text(
                          cat[i].nom,
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: IndexedStack(
                index: index,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Expanded(
                        child: ListView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "type2");
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 25, bottom: 30),
                                  child: Card(
                                    color: Colors.transparent,
                                    elevation: 10,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(
                                                (math.Random().nextDouble() *
                                                            0XFFFFFF)
                                                        .toInt() <<
                                                    0)
                                            .withOpacity(1),
                                      ),
                                      height: 250,
                                      width: 200,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Column(
                                            children: <Widget>[
                                              Stack(
                                                children: <Widget>[
                                                  Container(
                                                    height: 180,
                                                    width: 200,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topLeft: Radius
                                                                  .circular(10),
                                                              topRight: Radius
                                                                  .circular(
                                                                      10)),
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                          cat[index]
                                                              .produit[i]
                                                              .image,
                                                        ),
                                                        colorFilter:
                                                            ColorFilter.mode(
                                                                Colors
                                                                    .transparent,
                                                                BlendMode.hue),
                                                      ),
                                                      color: Colors.transparent,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 10,
                                                    top: 20,
                                                    child: Text(
                                                      "\$" +
                                                          cat[index]
                                                              .produit[i]
                                                              .prix
                                                              .toString(),
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 18),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 200,
                                            child: Text(
                                              cat[index].produit[i].description,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 120,
                                            child: Text(
                                              cat[index].produit[i].nom,
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Expanded(
                        child: ListView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "type2");
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 25, bottom: 30),
                                  child: Card(
                                    color: Colors.transparent,
                                    elevation: 10,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(
                                                (math.Random().nextDouble() *
                                                            0XFFFFFF)
                                                        .toInt() <<
                                                    0)
                                            .withOpacity(1),
                                      ),
                                      height: 250,
                                      width: 200,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Column(
                                            children: <Widget>[
                                              Stack(
                                                children: <Widget>[
                                                  Container(
                                                    height: 180,
                                                    width: 200,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topLeft: Radius
                                                                  .circular(10),
                                                              topRight: Radius
                                                                  .circular(
                                                                      10)),
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                          cat[index]
                                                              .produit[i]
                                                              .image,
                                                        ),
                                                        colorFilter:
                                                            ColorFilter.mode(
                                                                Colors
                                                                    .transparent,
                                                                BlendMode.hue),
                                                      ),
                                                      color: Colors.transparent,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 10,
                                                    top: 20,
                                                    child: Text(
                                                      "\$" +
                                                          cat[index]
                                                              .produit[i]
                                                              .prix
                                                              .toString(),
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 18),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 200,
                                            child: Text(
                                              cat[index].produit[i].description,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 120,
                                            child: Text(
                                              cat[index].produit[i].nom,
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Expanded(
                        child: ListView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "type2");
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 25, bottom: 30),
                                  child: Card(
                                    color: Colors.transparent,
                                    elevation: 10,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(
                                                (math.Random().nextDouble() *
                                                            0XFFFFFF)
                                                        .toInt() <<
                                                    0)
                                            .withOpacity(1),
                                      ),
                                      height: 250,
                                      width: 200,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Column(
                                            children: <Widget>[
                                              Stack(
                                                children: <Widget>[
                                                  Container(
                                                    height: 180,
                                                    width: 200,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topLeft: Radius
                                                                  .circular(10),
                                                              topRight: Radius
                                                                  .circular(
                                                                      10)),
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                          cat[index]
                                                              .produit[i]
                                                              .image,
                                                        ),
                                                        colorFilter:
                                                            ColorFilter.mode(
                                                                Colors.red,
                                                                BlendMode.hue),
                                                      ),
                                                      color: Colors.transparent,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 10,
                                                    top: 20,
                                                    child: Text(
                                                      "\$" +
                                                          cat[index]
                                                              .produit[i]
                                                              .prix
                                                              .toString(),
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 18),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 200,
                                            child: Text(
                                              cat[index].produit[i].description,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 120,
                                            child: Text(
                                              cat[index].produit[i].nom,
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      Expanded(
                        child: ListView.builder(
                            itemCount:
                                cat[index].produit.length /*prod.length*/,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, i) {
                              return InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, "type2");
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 10, left: 25, bottom: 30),
                                  child: Card(
                                    color: Colors.transparent,
                                    elevation: 10,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Color(
                                                (math.Random().nextDouble() *
                                                            0XFFFFFF)
                                                        .toInt() <<
                                                    0)
                                            .withOpacity(1),
                                      ),
                                      height: 250,
                                      width: 200,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Column(
                                            children: <Widget>[
                                              Stack(
                                                children: <Widget>[
                                                  Container(
                                                    height: 180,
                                                    width: 200,
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.only(
                                                              topLeft: Radius
                                                                  .circular(10),
                                                              topRight: Radius
                                                                  .circular(
                                                                      10)),
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                          cat[index]
                                                              .produit[i]
                                                              .image,
                                                        ),
                                                        colorFilter:
                                                            ColorFilter.mode(
                                                                Colors
                                                                    .transparent,
                                                                BlendMode.hue),
                                                      ),
                                                      color: Colors.transparent,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 10,
                                                    top: 20,
                                                    child: Text(
                                                      "\$" +
                                                          cat[index]
                                                              .produit[i]
                                                              .prix
                                                              .toString(),
                                                      style: TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 18),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 200,
                                            child: Text(
                                              cat[index].produit[i].description,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Container(
                                            padding: EdgeInsets.only(left: 15),
                                            width: 120,
                                            child: Text(
                                              cat[index].produit[i].nom,
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 20,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
