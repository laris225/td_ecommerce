import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../screen/type3t1.dart';
import '../screen/type3t2.dart';
import '../screen/type3t3.dart';
import '../screen/type3t4.dart';
import '../screen/type3t5.dart';

class Type3 extends StatefulWidget {
  @override
  _Type3State createState() => _Type3State();
}

class _Type3State extends State<Type3> {
  int pageIndex = 0;
  List<Widget> viewList = [
    Type3T1(),
    Type3T2(),
    Type3T3(),
    Type3T4(),
    Type3T5(),
  ];
  void onTappped(int index) {
    setState(() {
      pageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: viewList.elementAt(pageIndex),
      backgroundColor: Colors.red,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.red,
        currentIndex: pageIndex,
        onTap: onTappped,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.home,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(""),
            icon: Icon(
              FontAwesomeIcons.solidCompass,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.search,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(Icons.shopping_cart),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.bars,
            ),
          ),
        ],
      ),
    );
  }
}
