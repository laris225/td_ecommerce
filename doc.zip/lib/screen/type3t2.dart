import 'package:flutter/material.dart';

class Type3T2 extends StatelessWidget {
  const Type3T2({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.blue,
    );
  }
}
