import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../screen/type5t1.dart';
import '../screen/type5t2.dart';
import '../screen/type5t3.dart';
import '../screen/type5t4.dart';

class Type5 extends StatefulWidget {
  @override
  _Type5State createState() => _Type5State();
}

class _Type5State extends State<Type5> {
  int pageIndex = 0;
  List<Widget> viewList = [
    Type5T1(),
    Type5T2(),
    Type5T3(),
    Type5T4(),
  ];
  void onTappped(int index) {
    setState(() {
      pageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: viewList.elementAt(pageIndex),
      backgroundColor: Colors.white,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.red,
        currentIndex: pageIndex,
        onTap: onTappped,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.home,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(""),
            icon: Icon(
              Icons.view_module,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.shoppingBag,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(Icons.person_outline),
          ),
        ],
      ),
    );
  }
}
