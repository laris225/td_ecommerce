import 'package:flutter/material.dart';

class Type5T1 extends StatelessWidget {
  const Type5T1({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.blue,
    );
  }
}
