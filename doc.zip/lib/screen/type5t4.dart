import 'package:flutter/material.dart';

class Type5T4 extends StatelessWidget {
  const Type5T4({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.orange,
    );
  }
}
