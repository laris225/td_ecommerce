import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_page_indicator/flutter_page_indicator.dart';

class Type6 extends StatefulWidget {
  Type6({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _Type6 createState() => new _Type6();
}

class _Type6 extends State<Type6> {
  double size = 10.0;
  double activeSize = 10.0;

  PageController controller;

  @override
  void initState() {
    controller = new PageController();
    super.initState();
  }

  @override
  void didUpdateWidget(Type6 oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    var children = <Widget>[
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                Text(
                  "Back",
                  style: TextStyle(color: Colors.black),
                ),
                Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 205),
                      child: Row(
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Icon(
                                Icons.favorite_border,
                                color: Colors.black,
                              ),
                            ],
                          ),
                          Stack(
                            children: <Widget>[
                              Container(
                                child: IconButton(
                                  icon: Icon(Icons.shopping_basket),
                                  color: Colors.black,
                                  iconSize: 25,
                                  onPressed: () {},
                                ),
                              ),
                              Positioned(
                                right: 10,
                                top: 15,
                                child: CircleAvatar(
                                  maxRadius: 4,
                                  backgroundColor: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Stack(
              overflow: Overflow.visible,
              children: <Widget>[
                Container(
                  width: 180,
                  height: 247.8,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    image: DecorationImage(
                        image: AssetImage("images/affro2.png"),
                        fit: BoxFit.cover),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: -60,
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    alignment: Alignment.center,
                    height: 30,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(color: Color(0XFFE1CFC1), width: 2),
                        borderRadius: BorderRadius.circular(50)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Text(
                          "Play",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.grey[300]),
                        ),
                        Icon(
                          Icons.play_arrow,
                          color: Colors.grey[300],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: 246.1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0XFFE1CFC1),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                width: 170,
                                child: Text(
                                  "Beautiful Women Dress",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Text(
                                "\$159.99",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 1.15,
                            child: Text(
                              "Lorem impsun retuns confis retrius deantus neius opertinsue...",
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width / 1.1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(width: 50, child: Text("Select Size")),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "XS",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "S",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                      color: Color(0XFFE1CFC1), width: 1),
                                ),
                                child: Text(
                                  "M",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "L",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                Text(
                  "Back",
                  style: TextStyle(color: Colors.black),
                ),
                Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 205),
                      child: Row(
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Icon(
                                Icons.favorite_border,
                                color: Colors.black,
                              ),
                            ],
                          ),
                          Stack(
                            children: <Widget>[
                              Container(
                                child: IconButton(
                                  icon: Icon(Icons.shopping_basket),
                                  color: Colors.black,
                                  iconSize: 25,
                                  onPressed: () {},
                                ),
                              ),
                              Positioned(
                                right: 10,
                                top: 15,
                                child: CircleAvatar(
                                  maxRadius: 4,
                                  backgroundColor: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Stack(
              overflow: Overflow.visible,
              children: <Widget>[
                Container(
                  width: 180,
                  height: 247.8,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    image: DecorationImage(
                        image: AssetImage("images/affro2.png"),
                        fit: BoxFit.cover),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: -60,
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    alignment: Alignment.center,
                    height: 30,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(color: Color(0XFFE1CFC1), width: 2),
                        borderRadius: BorderRadius.circular(50)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Text(
                          "Play",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.grey[300]),
                        ),
                        Icon(
                          Icons.play_arrow,
                          color: Colors.grey[300],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: 246.1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0XFFE1CFC1),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                width: 170,
                                child: Text(
                                  "Beautiful Women Dress",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Text(
                                "\$159.99",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 1.15,
                            child: Text(
                              "Lorem impsun retuns confis retrius deantus neius opertinsue...",
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width / 1.1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(width: 50, child: Text("Select Size")),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "XS",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "S",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                      color: Color(0XFFE1CFC1), width: 1),
                                ),
                                child: Text(
                                  "M",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "L",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                Text(
                  "Back",
                  style: TextStyle(color: Colors.black),
                ),
                Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 205),
                      child: Row(
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Icon(
                                Icons.favorite_border,
                                color: Colors.black,
                              ),
                            ],
                          ),
                          Stack(
                            children: <Widget>[
                              Container(
                                child: IconButton(
                                  icon: Icon(Icons.shopping_basket),
                                  color: Colors.black,
                                  iconSize: 25,
                                  onPressed: () {},
                                ),
                              ),
                              Positioned(
                                right: 10,
                                top: 15,
                                child: CircleAvatar(
                                  maxRadius: 4,
                                  backgroundColor: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Stack(
              overflow: Overflow.visible,
              children: <Widget>[
                Container(
                  width: 180,
                  height: 247.8,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    image: DecorationImage(
                        image: AssetImage("images/affro2.png"),
                        fit: BoxFit.cover),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: -60,
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    alignment: Alignment.center,
                    height: 30,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(color: Color(0XFFE1CFC1), width: 2),
                        borderRadius: BorderRadius.circular(50)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Text(
                          "Play",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.grey[300]),
                        ),
                        Icon(
                          Icons.play_arrow,
                          color: Colors.grey[300],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: 246.1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0XFFE1CFC1),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                width: 170,
                                child: Text(
                                  "Beautiful Women Dress",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Text(
                                "\$159.99",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 1.15,
                            child: Text(
                              "Lorem impsun retuns confis retrius deantus neius opertinsue...",
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width / 1.1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(width: 50, child: Text("Select Size")),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "XS",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "S",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                      color: Color(0XFFE1CFC1), width: 1),
                                ),
                                child: Text(
                                  "M",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "L",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      new Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: <Widget>[
                IconButton(
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                Text(
                  "Back",
                  style: TextStyle(color: Colors.black),
                ),
                Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 205),
                      child: Row(
                        children: <Widget>[
                          Column(
                            children: <Widget>[
                              Icon(
                                Icons.favorite_border,
                                color: Colors.black,
                              ),
                            ],
                          ),
                          Stack(
                            children: <Widget>[
                              Container(
                                child: IconButton(
                                  icon: Icon(Icons.shopping_basket),
                                  color: Colors.black,
                                  iconSize: 25,
                                  onPressed: () {},
                                ),
                              ),
                              Positioned(
                                right: 10,
                                top: 15,
                                child: CircleAvatar(
                                  maxRadius: 4,
                                  backgroundColor: Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            Stack(
              overflow: Overflow.visible,
              children: <Widget>[
                Container(
                  width: 180,
                  height: 247.8,
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    image: DecorationImage(
                        image: AssetImage("images/affro2.png"),
                        fit: BoxFit.cover),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: -60,
                  child: Container(
                    padding: EdgeInsets.only(left: 5),
                    alignment: Alignment.center,
                    height: 30,
                    width: 80,
                    decoration: BoxDecoration(
                        color: Colors.transparent,
                        border: Border.all(color: Color(0XFFE1CFC1), width: 2),
                        borderRadius: BorderRadius.circular(50)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Text(
                          "Play",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                              color: Colors.grey[300]),
                        ),
                        Icon(
                          Icons.play_arrow,
                          color: Colors.grey[300],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: 246.1,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0XFFE1CFC1),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Container(
                                width: 170,
                                child: Text(
                                  "Beautiful Women Dress",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Text(
                                "\$159.99",
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: MediaQuery.of(context).size.width / 1.15,
                            child: Text(
                              "Lorem impsun retuns confis retrius deantus neius opertinsue...",
                              style:
                                  TextStyle(fontSize: 16, color: Colors.black),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width / 1.1,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              Container(width: 50, child: Text("Select Size")),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "XS",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "S",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                  border: Border.all(
                                      color: Color(0XFFE1CFC1), width: 1),
                                ),
                                child: Text(
                                  "M",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0XFFE1CFC1),
                                  border:
                                      Border.all(color: Colors.black, width: 1),
                                ),
                                child: Text(
                                  "L",
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.black),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ];

    return new Scaffold(
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: <Widget>[
            FractionallySizedBox(
              alignment: Alignment.topCenter,
              heightFactor: 0.88,
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: Container(
                      height: 200,
                      width: MediaQuery.of(context).size.width,
                      color: Color(0XFFB38B6D),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 0),
                        child: new Container(
                          width: 300,
                          child: new Stack(
                            children: <Widget>[
                              new PageView(
                                controller: controller,
                                children: children,
                              ),
                              new Align(
                                alignment: Alignment.centerLeft,
                                child: new PageIndicator(
                                    layout: PageIndicatorLayout.DROP,
                                    size: size,
                                    activeSize: activeSize,
                                    controller: controller,
                                    space: 8.0,
                                    count: 4,
                                    color: Colors.white,
                                    activeColor: Colors.orange),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            FractionallySizedBox(
              alignment: Alignment.bottomCenter,
              heightFactor: 0.17,
              child: Container(
                height: 60,
                color: Color(0XFFE1CFC1),
                width: MediaQuery.of(context).size.width,
                child: Row(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Card(
                        color: Colors.transparent,
                        elevation: 15,
                        child: Container(
                          alignment: Alignment.center,
                          height: 55,
                          width: MediaQuery.of(context).size.width / 1.1,
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 90),
                            child: Row(
                              children: <Widget>[
                                Text(
                                  "Add to my bag ",
                                  style: TextStyle(color: Colors.white),
                                ),
                                IconButton(
                                    icon: Icon(
                                      Icons.add,
                                      color: Colors.white,
                                    ),
                                    onPressed: null)
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
