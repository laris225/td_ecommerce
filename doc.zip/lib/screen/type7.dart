import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../screen/type7t1.dart';
import '../screen/type7t2.dart';
import '../screen/type7t3.dart';
import '../screen/type7t4.dart';
import '../screen/type7t5.dart';

class Type7 extends StatefulWidget {
  @override
  _Type7State createState() => _Type7State();
}

class _Type7State extends State<Type7> {
  int pageIndex = 0;
  List<Widget> viewList = [
    Type7T1(),
    Type7T2(),
    Type7T3(),
    Type7T4(),
    Type7T5(),
  ];
  void onTappped(int index) {
    setState(() {
      pageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: viewList.elementAt(pageIndex),
      backgroundColor: Colors.red,
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.red,
        currentIndex: pageIndex,
        onTap: onTappped,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.home,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(""),
            icon: Icon(
              FontAwesomeIcons.solidCompass,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.search,
            ),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(Icons.shopping_cart),
          ),
          BottomNavigationBarItem(
            title: Text(
              "",
            ),
            icon: Icon(
              FontAwesomeIcons.bars,
            ),
          ),
        ],
      ),
    );
  }
}
