// import 'package:flutter/material.dart';

// import '../providers/data/gridData.dart';

// class WidgGrid extends StatelessWidget {
//   const WidgGrid({Key key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//       child: FutureBuilder(future: getCategori(), builder: null),
//     );
//   }
// }
